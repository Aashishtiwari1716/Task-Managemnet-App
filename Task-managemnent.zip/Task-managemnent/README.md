# Task-managemnent

Task manager application built using **NODE JS** and **MongoDB**. It follows a **RESTFul API** design architecture. It's richly built with a simple scientific technique and best practices in the world of **API** design.

## Features

- Authentication and Security
- Sorting, Pagination, and Filtering
- Avatar upload


